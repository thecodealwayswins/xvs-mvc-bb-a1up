FINAL BURN DELTA v0.9.0-a

Brought to you by The Code Always Wins
https://www.youtube.com/c/TheCodeAlwaysWins

IMPORTANT: THIS ONLY WORKS FOR XMEN VS STREET FIGHTER, MARVEL VS CAPCOM AND BIG BLUE ARCADE 1UP GEN 3 PCBs.
THIS IS NOT AN OFFICIAL ARCADE1UP PATCH. USE RESPONSIBLY AND FOLLOW DIRECTIONS/NO WARRANTIES PROVIDED

HOW-TO-INSTALL

Right click on install-final-burn-delta.bat
Left Click "Run as Administrator"
Accept the confirmation prompts as needed on your PC for driver install.

Be sure to enable USB Debugging. If you've ran Team Encoder's Driver, then you should have this already
as they flash an image which is a different process.

Otherwise, check video here for how 
(timestamped already  starting point):
https://www.youtube.com/watch?v=II9OJyUnSFI&t=175s
Be sure to stop at 5 minutes! No need to install software on your PC for this patch beyond what's here.

Follow the instructions given in the prompt you'll see pop up as it does; should be very straightforward at this point.
[Be sure to read the instructions]