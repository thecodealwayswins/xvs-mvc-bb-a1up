FINAL BURN DELTA v1.0.0
YOGA FLAME/SHINKUU EDITION

Brought to you by The Code Always Wins
https://www.youtube.com/c/TheCodeAlwaysWins

IMPORTANT: THIS INPUT MOD IS ONLY DESIGNED FOR ARCADE 1UP SHINKUU HADOUKEN & YOGA FLAME PCBs.
THIS IS NOT AN OFFICIAL ARCADE1UP PATCH. USE RESPONSIBLY AND FOLLOW DIRECTIONS/NO WARRANTIES PROVIDED

HOW-TO-INSTALL

Right click on install-final-burn-delta(.bat) file
Left Click "Run as Administrator"
Accept the confirmation prompts as needed on your PC for driver install.

Be sure to enable USB Debugging on your cab, which instructions are provided in with the Shinkuu/Yoga release video @ https://youtu.be/W_XuXJ5OHSc

If for any reason the driver does not display splash screen, you can try to right click on kickstart-driver file, and left click on "Run as adminstrator" to re-enable and launch the driver manually.

Follow the instructions given in the prompt you'll see pop up as it does; should be very straightforward at this point.
[Be sure to read the instructions]